from __future__ import annotations

import json
import os
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import (
    BackgroundTasks,
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    Query,
    Request,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import ValidationError
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.rbac import attach_role_to_request, get_current_role, require_role
from app.db.base import Base
from app.db.models import AuditLog, DealRecord
from app.db.session import engine, get_db
from app.schemas import (
    DCFAssumptions,
    DealCreateRequest,
    DealStageUpdateRequest,
    DealStructureInput,
    DealSummary,
    FullAnalysisRequest,
    LocalDraftRequest,
    MasterDiligenceReport,
    NegotiationInput,
    RiskFlag,
    SynergyAssumptions,
    TargetScreeningInput,
    WarRoomMessageIn,
)
from app.services.deal_manager import DealLifecycleError, create_deal, update_deal_stage
from app.services.deal_structuring import (
    DealStructuringConfigurationError,
    DealStructuringError,
    generate_deal_structure,
)
from app.services.drafting import generate_local_draft
from app.services.document_scanner import (
    DocumentScannerConfigurationError,
    DocumentScannerDependencyError,
    DocumentScannerError,
    process_and_scan_pdf,
)
from app.services.financial_engine import (
    FinancialDataError,
    ValuationError,
    calculate_dcf,
    calculate_financial_ratios,
    dataframe_to_records,
    load_financial_csv,
)
from app.services.lifecycle_modules import run_module1_target_screening, run_module2_approach_summary
from app.services.local_qa import LocalQAError, answer_question_from_document
from app.services.negotiator import (
    NegotiationConfigurationError,
    NegotiationEngineError,
    generate_negotiation_strategy,
)
from app.services.orchestrator import run_full_analysis
from app.services.pitchbook import create_pitchbook
from app.services.public_data import (
    PublicDataError,
    get_fred_series,
    get_reference_datasets,
    get_sec_companyfacts,
    get_stooq_prices,
    get_treasury_yields,
)
from app.services.synthetic_data import (
    SyntheticDataError,
    list_synthetic_datasets,
    load_synthetic_dataset,
)
from app.services.synergy import SynergyCalculationError, calculate_synergies
from app.services.war_room import get_war_room_messages, save_war_room_message
from app.services.ai_provider import has_valid_anthropic_key, resolve_ai_provider
from app.services.anthropic_client import (
    AnthropicAuthenticationError,
    AnthropicClientError,
    AnthropicConfigurationError,
    AnthropicRequestError,
    check_anthropic_connectivity,
)

settings = get_settings()


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title=settings.app_name,
    version="3.0.0",
    description="QuantumBlack M&A Deal Operating System API",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class WarRoomConnectionManager:
    def __init__(self) -> None:
        self._connections: dict[str, list[WebSocket]] = {}

    async def connect(self, deal_id: str, websocket: WebSocket) -> None:
        await websocket.accept()
        self._connections.setdefault(deal_id, []).append(websocket)

    def disconnect(self, deal_id: str, websocket: WebSocket) -> None:
        if deal_id not in self._connections:
            return
        self._connections[deal_id] = [w for w in self._connections[deal_id] if w is not websocket]
        if not self._connections[deal_id]:
            del self._connections[deal_id]

    async def broadcast(self, deal_id: str, payload: dict) -> None:
        for ws in list(self._connections.get(deal_id, [])):
            try:
                await ws.send_json(payload)
            except Exception:
                self.disconnect(deal_id, ws)


war_room_manager = WarRoomConnectionManager()


@app.middleware("http")
async def role_context_middleware(request: Request, call_next):
    header_role = request.headers.get("x-user-role")
    role = header_role.lower() if header_role else settings.default_role.lower()
    attach_role_to_request(request, role)
    return await call_next(request)


def _safe_remove_file(path: str) -> None:
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        return


def _write_audit_log(db: Session, deal_id: str, role: str, action: str, details: str = "") -> None:
    db.add(
        AuditLog(
            deal_id=deal_id,
            actor_role=role,
            action=action,
            details=details,
        )
    )
    db.commit()


def _iso_utc(value: datetime) -> str:
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    else:
        value = value.astimezone(timezone.utc)
    return value.isoformat()


def _save_master_report(db: Session, report: MasterDiligenceReport) -> DealRecord:
    existing = db.get(DealRecord, report.deal_id)
    if existing is None:
        record = DealRecord(id=report.deal_id)
        db.add(record)
    else:
        record = existing

    record.stage = "m8_reality"
    record.status = "completed"
    record.company_a_financials = report.company_a_financials
    record.company_b_financials = report.company_b_financials
    record.valuation = report.valuation
    record.synergies = report.synergies
    record.legal_risks = report.legal_risks
    record.deal_structure = report.deal_structure
    record.negotiation_strategy = report.negotiation_strategy
    record.status_log = report.status_log

    db.commit()
    db.refresh(record)
    return record


@app.get("/")
def root():
    return {"message": f"{settings.app_name} API is running.", "version": app.version}


@app.get(f"{settings.api_v1_prefix}/health")
def health():
    return {"status": "ok", "service": settings.app_name}


@app.get(f"{settings.api_v1_prefix}/health/llm")
def llm_health(live_check: bool = Query(default=True)):
    provider = resolve_ai_provider()
    if provider == "local":
        return {
            "status": "ok",
            "provider": "local",
            "mode": "free_mvp",
            "detail": "Local deterministic mode enabled. No paid API key required.",
        }

    if not has_valid_anthropic_key():
        return {
            "status": "degraded",
            "provider": "anthropic",
            "model": settings.anthropic_model,
            "detail": "Anthropic mode requested but ANTHROPIC_API_KEY is missing or invalid.",
        }

    if not live_check:
        return {
            "status": "configured",
            "provider": "anthropic",
            "model": settings.anthropic_model,
            "detail": "Set live_check=true to validate upstream Anthropic authentication.",
        }

    try:
        ping = check_anthropic_connectivity(model=settings.anthropic_model)
        return {
            "status": "ok",
            "provider": ping["provider"],
            "model": ping["model"],
            "request_id": ping["request_id"],
        }
    except AnthropicConfigurationError as exc:
        return {
            "status": "degraded",
            "provider": "anthropic",
            "detail": str(exc),
        }
    except AnthropicAuthenticationError as exc:
        raise HTTPException(
            status_code=401,
            detail=f"Anthropic authentication failed: {exc.detail}",
        ) from exc
    except AnthropicRequestError as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Anthropic upstream request failed ({exc.status_code}): {exc.detail}",
        ) from exc
    except AnthropicClientError as exc:
        raise HTTPException(status_code=503, detail=f"Anthropic health check failed: {exc}") from exc


@app.post(
    f"{settings.api_v1_prefix}/deals",
    response_model=DealSummary,
    dependencies=[Depends(require_role("associate"))],
)
def create_deal_record(
    payload: DealCreateRequest,
    db: Session = Depends(get_db),
    user_role: str = Depends(get_current_role),
):
    deal = create_deal(db, payload)
    _write_audit_log(
        db=db,
        deal_id=deal.id,
        role=user_role,
        action="create_deal",
        details=json.dumps({"deal_name": payload.deal_name}),
    )
    return DealSummary(
        id=deal.id,
        deal_name=deal.deal_name,
        stage=deal.stage,
        status=deal.status,
        created_at=_iso_utc(deal.created_at),
        updated_at=_iso_utc(deal.updated_at),
    )


@app.patch(
    f"{settings.api_v1_prefix}/deals/{{deal_id}}/stage",
    response_model=DealSummary,
    dependencies=[Depends(require_role("vp"))],
)
def update_deal_stage_endpoint(
    deal_id: str,
    payload: DealStageUpdateRequest,
    db: Session = Depends(get_db),
    user_role: str = Depends(get_current_role),
):
    deal = db.get(DealRecord, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="Deal record not found.")
    try:
        updated = update_deal_stage(db, deal, payload)
    except DealLifecycleError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    _write_audit_log(
        db=db,
        deal_id=updated.id,
        role=user_role,
        action="update_stage",
        details=json.dumps({"stage": payload.stage, "status": payload.status}),
    )
    return DealSummary(
        id=updated.id,
        deal_name=updated.deal_name,
        stage=updated.stage,
        status=updated.status,
        created_at=_iso_utc(updated.created_at),
        updated_at=_iso_utc(updated.updated_at),
    )


# Module 1 (Hunt)
@app.post(
    f"{settings.api_v1_prefix}/modules/m1/screen-targets",
    dependencies=[Depends(require_role("analyst"))],
)
def module1_screen_targets(payload: TargetScreeningInput):
    result = run_module1_target_screening(payload)
    return {"status": "success", "module": "m1_hunt", "data": result.model_dump()}


# Module 2 (Approach)
@app.get(
    f"{settings.api_v1_prefix}/modules/m2/approach-summary",
    dependencies=[Depends(require_role("associate"))],
)
def module2_approach_summary(target_name: str = Query(..., min_length=2, max_length=120)):
    return {
        "status": "success",
        "module": "m2_approach",
        "data": run_module2_approach_summary(target_name),
    }


@app.post(
    f"{settings.api_v1_prefix}/draft-document/",
    dependencies=[Depends(require_role("associate"))],
)
def draft_local_document(payload: LocalDraftRequest):
    draft = generate_local_draft(payload)
    return {"status": "success", "draft": draft.model_dump()}


@app.get(
    f"{settings.api_v1_prefix}/deals/{{deal_id}}/war-room/messages",
    dependencies=[Depends(require_role("analyst"))],
)
def list_war_room_messages(
    deal_id: str,
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    if db.get(DealRecord, deal_id) is None:
        raise HTTPException(status_code=404, detail="Deal record not found.")
    return {
        "status": "success",
        "deal_id": deal_id,
        "messages": [m.model_dump() for m in get_war_room_messages(db, deal_id, limit)],
    }


@app.post(
    f"{settings.api_v1_prefix}/deals/{{deal_id}}/war-room/messages",
    dependencies=[Depends(require_role("associate"))],
)
async def post_war_room_message(
    deal_id: str,
    payload: WarRoomMessageIn,
    db: Session = Depends(get_db),
    user_role: str = Depends(get_current_role),
):
    if db.get(DealRecord, deal_id) is None:
        raise HTTPException(status_code=404, detail="Deal record not found.")
    msg = save_war_room_message(db, deal_id, user_role, payload)
    await war_room_manager.broadcast(deal_id, msg.model_dump())
    return {"status": "success", "message": msg.model_dump()}


@app.websocket(f"{settings.api_v1_prefix}/ws/war-room/{{deal_id}}")
async def war_room_websocket(deal_id: str, websocket: WebSocket):
    role = websocket.headers.get("x-user-role", settings.default_role)
    await war_room_manager.connect(deal_id, websocket)
    try:
        await war_room_manager.broadcast(
            deal_id,
            {
                "system_event": "join",
                "deal_id": deal_id,
                "sender_role": role,
            },
        )
        while True:
            payload = await websocket.receive_json()
            payload.setdefault("deal_id", deal_id)
            payload.setdefault("sender_role", role)
            await war_room_manager.broadcast(deal_id, payload)
    except WebSocketDisconnect:
        war_room_manager.disconnect(deal_id, websocket)
        await war_room_manager.broadcast(
            deal_id,
            {
                "system_event": "leave",
                "deal_id": deal_id,
                "sender_role": role,
            },
        )


# Phase 1 financial ratios
@app.post(f"{settings.api_v1_prefix}/financial/ratios")
async def analyze_financial_ratios(
    company_a_file: UploadFile = File(...),
    company_b_file: UploadFile = File(...),
):
    try:
        company_a_bytes = await company_a_file.read()
        company_b_bytes = await company_b_file.read()
        if not company_a_bytes or not company_b_bytes:
            raise HTTPException(status_code=400, detail="Both uploaded CSV files must be non-empty.")

        cleaned_a, warnings_a = load_financial_csv(company_a_bytes, "Company A")
        cleaned_b, warnings_b = load_financial_csv(company_b_bytes, "Company B")
        ratios_a = calculate_financial_ratios(cleaned_a)
        ratios_b = calculate_financial_ratios(cleaned_b)
        return {
            "status": "success",
            "companies": {
                "company_a": {
                    "warnings": warnings_a,
                    "ratios": dataframe_to_records(ratios_a),
                },
                "company_b": {
                    "warnings": warnings_b,
                    "ratios": dataframe_to_records(ratios_b),
                },
            },
        }
    except FinancialDataError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Financial ratio engine failed: {exc}") from exc


# Phase 1 DCF
@app.post(f"{settings.api_v1_prefix}/valuation/dcf")
def run_dcf_valuation(assumptions: DCFAssumptions):
    try:
        return {"status": "success", "valuation": calculate_dcf(assumptions)}
    except ValuationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"DCF engine failed: {exc}") from exc


# Phase 2 synergy
@app.post(f"{settings.api_v1_prefix}/calculate-synergies/")
def run_synergy_engine(assumptions: SynergyAssumptions):
    try:
        return {"status": "success", "synergy_analysis": calculate_synergies(assumptions)}
    except SynergyCalculationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Synergy engine failed: {exc}") from exc


# Phase 3 legal scan
@app.post(f"{settings.api_v1_prefix}/scan-document/")
async def scan_legal_document(file: UploadFile = File(...)):
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="Uploaded PDF is empty.")

    try:
        scan_results = process_and_scan_pdf(file_bytes, file.filename)
        return {"status": "success", "diligence_report": scan_results.model_dump()}
    except DocumentScannerConfigurationError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    except DocumentScannerDependencyError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except DocumentScannerError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Document scan failed: {exc}") from exc


@app.post(f"{settings.api_v1_prefix}/document-qa/")
async def document_qa(
    file: UploadFile = File(...),
    question: str = Form(..., min_length=3, max_length=500),
    top_k: int = Form(default=4, ge=1, le=8),
):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Missing file name.")
    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="Uploaded document is empty.")
    try:
        answer = answer_question_from_document(file_bytes, file.filename, question, top_k=top_k)
        return {"status": "success", "qa": answer.model_dump()}
    except LocalQAError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Document Q&A failed: {exc}") from exc


# Phase 4/5 structuring
@app.post(f"{settings.api_v1_prefix}/structure-deal/")
def structure_ma_deal(payload: DealStructureInput):
    try:
        result = generate_deal_structure(payload)
        return {"status": "success", "deal_structure": result.model_dump()}
    except DealStructuringConfigurationError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    except DealStructuringError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Structuring engine failed: {exc}") from exc


# Phase 6 negotiation
@app.post(
    f"{settings.api_v1_prefix}/negotiation-strategy/",
    dependencies=[Depends(require_role("associate"))],
)
def calculate_negotiation_strategy(payload: NegotiationInput):
    try:
        result = generate_negotiation_strategy(payload)
        return {"status": "success", "negotiation_playbook": result.model_dump()}
    except NegotiationConfigurationError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc
    except NegotiationEngineError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Negotiation engine failed: {exc}") from exc


# Phase 7 orchestrator
@app.post(
    f"{settings.api_v1_prefix}/run-full-analysis/",
    response_model=MasterDiligenceReport,
    dependencies=[Depends(require_role("director"))],
)
async def run_full_orchestration(
    request: Request,
    company_a_file: UploadFile = File(...),
    company_b_file: UploadFile = File(...),
    orchestration_payload: str = Form(..., description="JSON string for FullAnalysisRequest"),
    legal_pdf: UploadFile | None = File(default=None),
    db: Session = Depends(get_db),
    user_role: str = Depends(get_current_role),
):
    try:
        payload = FullAnalysisRequest.model_validate_json(orchestration_payload)
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=exc.errors()) from exc

    company_a_bytes = await company_a_file.read()
    company_b_bytes = await company_b_file.read()
    if not company_a_bytes or not company_b_bytes:
        raise HTTPException(status_code=400, detail="Both financial CSV uploads are required.")

    legal_pdf_bytes = None
    legal_pdf_name = None
    if legal_pdf is not None:
        legal_pdf_name = legal_pdf.filename
        legal_pdf_bytes = await legal_pdf.read()

    report = run_full_analysis(
        deal_id=str(uuid.uuid4()),
        company_a_bytes=company_a_bytes,
        company_b_bytes=company_b_bytes,
        payload=payload,
        legal_pdf_bytes=legal_pdf_bytes,
        legal_pdf_name=legal_pdf_name,
    )

    _save_master_report(db, report)
    _write_audit_log(
        db=db,
        deal_id=report.deal_id,
        role=user_role,
        action="run_full_analysis",
        details=json.dumps({"status_log_count": len(report.status_log)}),
    )

    return report


# Phase 8 pitchbook
@app.post(
    f"{settings.api_v1_prefix}/download-pitchbook/",
    dependencies=[Depends(require_role("associate"))],
)
def download_presentation(
    report: MasterDiligenceReport,
    background_tasks: BackgroundTasks,
):
    try:
        filepath = create_pitchbook(report)
        background_tasks.add_task(_safe_remove_file, filepath)
        return FileResponse(
            path=filepath,
            filename=f"MA_Pitchbook_{report.deal_id}.pptx",
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Pitchbook generation failed: {exc}") from exc


@app.get(
    f"{settings.api_v1_prefix}/deals/{{deal_id}}/pitchbook",
    dependencies=[Depends(require_role("associate"))],
)
def download_presentation_from_deal(
    deal_id: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    record = db.get(DealRecord, deal_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Deal record not found.")
    report = MasterDiligenceReport(
        deal_id=record.id,
        company_a_financials=record.company_a_financials or {},
        company_b_financials=record.company_b_financials or {},
        valuation=record.valuation,
        synergies=record.synergies or {},
        legal_risks=record.legal_risks,
        deal_structure=record.deal_structure,
        negotiation_strategy=record.negotiation_strategy,
        status_log=record.status_log or [],
    )
    try:
        filepath = create_pitchbook(report)
        background_tasks.add_task(_safe_remove_file, filepath)
        return FileResponse(
            path=filepath,
            filename=f"MA_Pitchbook_{deal_id}.pptx",
            media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Pitchbook generation failed: {exc}") from exc


@app.get(f"{settings.api_v1_prefix}/public-data/references")
def public_data_references():
    return {"status": "success", "references": get_reference_datasets()}


@app.get(f"{settings.api_v1_prefix}/public-data/fred/{{series_id}}")
def public_data_fred(series_id: str, limit: int = Query(default=20, ge=1, le=200)):
    try:
        return {"status": "success", "data": get_fred_series(series_id=series_id, limit=limit).model_dump()}
    except PublicDataError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_v1_prefix}/public-data/treasury-yields")
def public_data_treasury(limit: int = Query(default=20, ge=1, le=200)):
    try:
        return {"status": "success", "data": get_treasury_yields(limit=limit).model_dump()}
    except PublicDataError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_v1_prefix}/public-data/stooq/{{symbol}}")
def public_data_stooq(symbol: str, limit: int = Query(default=20, ge=1, le=200)):
    try:
        return {"status": "success", "data": get_stooq_prices(symbol=symbol, limit=limit).model_dump()}
    except PublicDataError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_v1_prefix}/public-data/sec/companyfacts/{{cik}}")
def public_data_sec_companyfacts(cik: str):
    try:
        return {"status": "success", "data": get_sec_companyfacts(cik)}
    except PublicDataError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_v1_prefix}/synthetic-data")
def synthetic_data_index():
    return {"status": "success", "datasets": list_synthetic_datasets()}


@app.get(f"{settings.api_v1_prefix}/synthetic-data/{{dataset_name}}")
def synthetic_data_payload(dataset_name: str):
    try:
        return {"status": "success", "dataset": load_synthetic_dataset(dataset_name)}
    except SyntheticDataError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get(
    f"{settings.api_v1_prefix}/deals/{{deal_id}}",
    dependencies=[Depends(require_role("analyst"))],
)
def get_deal(deal_id: str, db: Session = Depends(get_db)):
    record = db.get(DealRecord, deal_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Deal record not found.")
    return {
        "id": record.id,
        "deal_name": record.deal_name,
        "stage": record.stage,
        "status": record.status,
        "company_a_financials": record.company_a_financials,
        "company_b_financials": record.company_b_financials,
        "valuation": record.valuation,
        "synergies": record.synergies,
        "legal_risks": record.legal_risks,
        "deal_structure": record.deal_structure,
        "negotiation_strategy": record.negotiation_strategy,
        "status_log": record.status_log,
        "created_at": _iso_utc(record.created_at),
        "updated_at": _iso_utc(record.updated_at),
    }


@app.get(
    f"{settings.api_v1_prefix}/deals",
    dependencies=[Depends(require_role("analyst"))],
)
def list_deals(limit: int = Query(default=20, ge=1, le=200), db: Session = Depends(get_db)):
    rows = db.query(DealRecord).order_by(DealRecord.created_at.desc()).limit(limit).all()
    return [
        {
            "id": r.id,
            "deal_name": r.deal_name,
            "stage": r.stage,
            "status": r.status,
            "created_at": _iso_utc(r.created_at),
            "updated_at": _iso_utc(r.updated_at),
        }
        for r in rows
    ]
