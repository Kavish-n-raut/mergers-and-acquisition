from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    app_name: str = Field(default="QuantumBlack M&A Deal OS", alias="APP_NAME")
    environment: str = Field(default="development", alias="ENVIRONMENT")
    api_v1_prefix: str = Field(default="/api/v1", alias="API_V1_PREFIX")

    database_url: str = Field(default="sqlite:///./ma_deal_os.db", alias="DATABASE_URL")
    default_role: str = Field(default="analyst", alias="DEFAULT_ROLE")

    ai_provider: Literal["local", "anthropic"] = Field(default="local", alias="AI_PROVIDER")
    use_anthropic: bool = Field(default=False, alias="USE_ANTHROPIC")
    anthropic_api_key: str | None = Field(default=None, alias="ANTHROPIC_API_KEY")
    anthropic_model: str = Field(
        default="claude-sonnet-4-20250514", alias="ANTHROPIC_MODEL"
    )
    anthropic_version: str = Field(default="2023-06-01", alias="ANTHROPIC_VERSION")
    local_embedding_model: str = Field(
        default="sentence-transformers/all-MiniLM-L6-v2", alias="LOCAL_EMBEDDING_MODEL"
    )

    synergy_npv_multiple: float = Field(default=5.0, alias="SYNERGY_NPV_MULTIPLE")
    pitchbook_output_dir: str = Field(default="generated_pitchbooks", alias="PITCHBOOK_OUTPUT_DIR")

    @field_validator("anthropic_api_key")
    @classmethod
    def validate_anthropic_api_key(cls, value: str | None) -> str | None:
        if value is None:
            return None

        normalized = value.strip()
        if not normalized:
            return None

        placeholder_values = {
            "your_real_key",
            "your_real_key_here",
            "your_key_here",
            "replace_me",
            "changeme",
        }
        lowered = normalized.lower()
        if lowered in placeholder_values or lowered.startswith("your_"):
            return None

        # Keep key optional and non-blocking for local MVP mode. Runtime provider checks
        # decide whether Anthropic should actually be used.
        return normalized


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
