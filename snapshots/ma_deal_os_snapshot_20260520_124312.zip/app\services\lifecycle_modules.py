from __future__ import annotations

from app.schemas import TargetScreeningInput, TargetScreeningResult


def run_module1_target_screening(payload: TargetScreeningInput) -> TargetScreeningResult:
    # PRD-aligned placeholder for Hunt module. Replace with Bloomberg/CapIQ + Sentiment Radar ingestion.
    candidates = [
        {
            "name": "Aster Dynamics",
            "sector": payload.sector,
            "geography": payload.geography,
            "estimated_revenue": max(payload.min_revenue, 25_000_000.0),
        },
        {
            "name": "Nexa Holdings",
            "sector": payload.sector,
            "geography": payload.geography,
            "estimated_revenue": min(payload.max_revenue, 90_000_000.0),
        },
    ]
    return TargetScreeningResult(
        shortlist=candidates,
        sentiment_summary="Stable sentiment with mild leadership-transition watch signals.",
        competing_bid_risk_score=0.34,
    )


def run_module2_approach_summary(target_name: str) -> dict:
    return {
        "target_name": target_name,
        "nda_status": "draft_generated",
        "advisor_conflict_graph_status": "pending_external_feed",
        "normalized_financials_status": "ready_for_module_3",
    }

