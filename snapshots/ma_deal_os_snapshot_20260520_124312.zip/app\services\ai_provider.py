from __future__ import annotations

import os
from typing import Literal

from dotenv import load_dotenv

AIProvider = Literal["local", "anthropic"]


def _parse_bool_env(value: str | None) -> bool:
    if value is None:
        return False
    normalized = value.strip().lower()
    return normalized in {"1", "true", "yes", "y", "on"}


def resolve_ai_provider() -> AIProvider:
    load_dotenv(override=False)
    provider = os.getenv("AI_PROVIDER", "local").strip().lower()
    use_anthropic = _parse_bool_env(os.getenv("USE_ANTHROPIC", "false"))
    if use_anthropic or provider == "anthropic":
        return "anthropic"
    return "local"


def get_anthropic_api_key() -> str | None:
    load_dotenv(override=False)
    key = (os.getenv("ANTHROPIC_API_KEY") or "").strip()
    if not key:
        return None
    return key


def has_valid_anthropic_key() -> bool:
    key = get_anthropic_api_key()
    return bool(key and key.startswith("sk-ant-"))


def should_use_anthropic() -> bool:
    return resolve_ai_provider() == "anthropic" and has_valid_anthropic_key()

