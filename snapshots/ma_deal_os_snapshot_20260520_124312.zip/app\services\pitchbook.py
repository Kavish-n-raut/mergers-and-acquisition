from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.schemas import MasterDiligenceReport


class PitchbookGenerationError(ValueError):
    pass


class PitchbookDependencyError(PitchbookGenerationError):
    pass


def _import_pptx() -> Any:
    try:
        from pptx import Presentation
    except ImportError as exc:
        raise PitchbookDependencyError(
            "python-pptx is not installed. Install with `pip install python-pptx`."
        ) from exc
    return Presentation


def _safe_float(value: Any) -> float | None:
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _currency(value: float | None) -> str:
    return "N/A" if value is None else f"${value:,.2f}"


def generate_pitchbook(master_json: MasterDiligenceReport | dict[str, Any]) -> str:
    report = (
        master_json
        if isinstance(master_json, MasterDiligenceReport)
        else MasterDiligenceReport.model_validate(master_json)
    )

    Presentation = _import_pptx()
    prs = Presentation()

    # Slide 1
    slide = prs.slides.add_slide(prs.slide_layouts[0])
    slide.shapes.title.text = "Project Alpha: M&A Advisory Overview"
    subtitle = slide.placeholders[1]
    subtitle.text = (
        f"Deal ID: {report.deal_id}\n"
        "AI-Generated Deal Strategy & Diligence\n"
        f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}"
    )

    # Slide 2
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    slide.shapes.title.text = "Financial Valuation & Synergies"
    tf = slide.shapes.placeholders[1].text_frame
    tf.clear()

    target_revenue = _safe_float(report.company_b_financials.get("latest_revenue"))
    total_synergy = _safe_float(
        report.synergies.get("financial_synergies", {}).get("total_annual_synergy")
    )
    enterprise_value = _safe_float((report.valuation or {}).get("enterprise_value"))

    tf.paragraphs[0].text = f"Target Enterprise Value: {_currency(enterprise_value)}"
    p = tf.add_paragraph()
    p.text = f"Target Base Revenue: {_currency(target_revenue)}"
    p = tf.add_paragraph()
    p.text = f"Estimated Annual Synergies: {_currency(total_synergy)}"

    # Slide 3
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    slide.shapes.title.text = "Due Diligence: Key Legal Risks"
    tf = slide.shapes.placeholders[1].text_frame
    tf.clear()

    risks = ((report.legal_risks or {}).get("risks") or [])[:6]
    if risks:
        tf.paragraphs[0].text = "AI Scanner flagged the following:"
        for risk in risks:
            p = tf.add_paragraph()
            p.text = (
                f"[{risk.get('severity', 'Unknown')}] {risk.get('risk_category', 'Risk')}: "
                f"{risk.get('ai_explanation', '')}"
            )
            p.level = 1
    else:
        tf.paragraphs[0].text = "No major legal risks identified or scan bypassed."

    # Slide 4
    slide = prs.slides.add_slide(prs.slide_layouts[1])
    slide.shapes.title.text = "Strategic Recommendation & Tactics"
    tf = slide.shapes.placeholders[1].text_frame
    tf.clear()

    deal_structure = (report.deal_structure or {}).get("recommended_structure", "N/A")
    opening_bid = _safe_float((report.negotiation_strategy or {}).get("opening_bid_price"))
    walk_away = _safe_float((report.negotiation_strategy or {}).get("walk_away_price"))
    tactics = (report.negotiation_strategy or {}).get("tactical_moves", [])

    tf.paragraphs[0].text = f"Recommended Structure: {deal_structure}"
    p = tf.add_paragraph()
    p.text = f"Suggested Opening Bid: {_currency(opening_bid)}"
    p = tf.add_paragraph()
    p.text = f"Hard Walk-Away Price: {_currency(walk_away)}"

    if tactics:
        p = tf.add_paragraph()
        p.text = "Tactics:"
        for tactic in tactics[:5]:
            p = tf.add_paragraph()
            p.text = str(tactic)
            p.level = 1
    else:
        p = tf.add_paragraph()
        p.text = "Strategy generation skipped or unavailable."

    out_dir = Path(os.getenv("PITCHBOOK_OUTPUT_DIR", "generated_pitchbooks"))
    out_dir.mkdir(parents=True, exist_ok=True)
    filepath = out_dir / f"MA_Pitchbook_{report.deal_id}.pptx"
    prs.save(str(filepath))
    return str(filepath.resolve())


def create_pitchbook(report: MasterDiligenceReport | dict[str, Any]) -> str:
    return generate_pitchbook(report)

