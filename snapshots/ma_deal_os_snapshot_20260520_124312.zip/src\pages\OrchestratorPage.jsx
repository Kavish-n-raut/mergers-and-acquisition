import React, { useState } from "react";
import { runFullAnalysis } from "../lib/api";

const defaultPayload = {
  dcf_assumptions: {
    wacc: 0.1,
    terminal_growth_rate: 0.025,
    free_cash_flows: [1200000, 1500000, 1700000, 2000000, 2300000],
  },
  acquirer_market_cap: 95000000,
  synergy_assumptions: {
    company_a_revenue: 50000000,
    company_b_revenue: 12000000,
    company_b_opex: 4500000,
    cost_reduction_pct: 0.1,
    cross_sell_pct: 0.05,
    market_compatibility_score: 7,
    tech_stack_compatibility: 6,
  },
};

export default function OrchestratorPage() {
  const [companyA, setCompanyA] = useState(null);
  const [companyB, setCompanyB] = useState(null);
  const [legalPdf, setLegalPdf] = useState(null);
  const [payloadText, setPayloadText] = useState(JSON.stringify(defaultPayload, null, 2));
  const [response, setResponse] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async () => {
    if (!companyA || !companyB) {
      setError("Please upload both acquirer and target financial CSV files.");
      return;
    }
    setLoading(true);
    setError("");
    setResponse(null);
    try {
      JSON.parse(payloadText);
      const formData = new FormData();
      formData.append("company_a_file", companyA);
      formData.append("company_b_file", companyB);
      formData.append("orchestration_payload", payloadText);
      if (legalPdf) formData.append("legal_pdf", legalPdf);

      const result = await runFullAnalysis(formData);
      setResponse(result);
    } catch (e) {
      if (e instanceof SyntaxError) {
        setError("Invalid JSON in orchestration payload.");
      } else {
        setError(e?.response?.data?.detail || e.message || "Integrated analysis execution failed.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-grid pipeline-grid">
      <section className="panel">
        <div className="panel-header">
          <h2>Integrated Analysis Orchestration</h2>
          <span className="chip chip-live">M3 to M8</span>
        </div>
        <p className="muted">
          Upload financial inputs, optionally include legal documentation, and execute the fault-tolerant multi-engine workflow.
        </p>
        <div className="form-stack">
          <label>
            Acquirer Financials (CSV)
            <input type="file" accept=".csv" onChange={(e) => setCompanyA(e.target.files?.[0] || null)} />
          </label>
          <label>
            Target Financials (CSV)
            <input type="file" accept=".csv" onChange={(e) => setCompanyB(e.target.files?.[0] || null)} />
          </label>
          <label>
            Legal Agreement Pack (PDF, optional)
            <input type="file" accept=".pdf" onChange={(e) => setLegalPdf(e.target.files?.[0] || null)} />
          </label>
          <label>
            Analysis Assumptions (JSON)
            <textarea rows={16} value={payloadText} onChange={(e) => setPayloadText(e.target.value)} />
          </label>
          <button onClick={onSubmit} disabled={loading}>
            {loading ? "Executing Analysis..." : "Execute Full Analysis"}
          </button>
        </div>
        {error && <p className="error-text">{error}</p>}
      </section>

      <section className="panel">
        <div className="panel-header">
          <h3>Consolidated Diligence Report</h3>
          <span className="chip">{response ? "Generated" : "Awaiting Execution"}</span>
        </div>
        {response ? (
          <pre className="json-view">{JSON.stringify(response, null, 2)}</pre>
        ) : (
          <p className="muted">Execute the workflow to view consolidated output.</p>
        )}
      </section>
    </div>
  );
}
