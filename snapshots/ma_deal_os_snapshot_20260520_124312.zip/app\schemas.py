from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, StrictFloat, StrictInt, model_validator


class TargetScreeningInput(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    sector: str = Field(..., min_length=2, max_length=100)
    geography: str = Field(..., min_length=2, max_length=100)
    min_revenue: StrictFloat = Field(..., ge=0.0)
    max_revenue: StrictFloat = Field(..., gt=0.0)

    @model_validator(mode="after")
    def check_revenue_bounds(self) -> "TargetScreeningInput":
        if self.min_revenue > self.max_revenue:
            raise ValueError("min_revenue cannot exceed max_revenue.")
        return self


class TargetScreeningResult(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    shortlist: list[dict[str, Any]] = Field(default_factory=list)
    sentiment_summary: str = ""
    competing_bid_risk_score: StrictFloat = Field(default=0.0, ge=0.0, le=1.0)


class DCFAssumptions(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    wacc: StrictFloat = Field(..., gt=0.0, lt=1.0)
    terminal_growth_rate: StrictFloat = Field(..., ge=0.0, lt=1.0)
    free_cash_flows: list[StrictFloat] = Field(..., min_length=1)

    @model_validator(mode="after")
    def validate_terminal_growth(self) -> "DCFAssumptions":
        if self.terminal_growth_rate >= self.wacc:
            raise ValueError("terminal_growth_rate must be less than wacc.")
        return self


class SynergyAssumptions(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    company_a_revenue: StrictFloat = Field(..., ge=0.0)
    company_b_revenue: StrictFloat = Field(..., ge=0.0)
    company_b_opex: StrictFloat = Field(..., ge=0.0)
    cost_reduction_pct: StrictFloat = Field(..., ge=0.0, le=1.0)
    cross_sell_pct: StrictFloat = Field(..., ge=0.0, le=1.0)
    market_compatibility_score: StrictInt = Field(..., ge=1, le=10)
    tech_stack_compatibility: StrictInt = Field(default=5, ge=1, le=10)


class RiskFlag(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    risk_category: str = Field(..., min_length=3, max_length=120)
    severity: Literal["High", "Medium", "Low"]
    quoted_text: str = Field(..., min_length=10)
    ai_explanation: str = Field(..., min_length=10, max_length=1200)


class DocumentScanResult(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    document_name: str = Field(..., min_length=1, max_length=255)
    total_risks_found: StrictInt = Field(..., ge=0)
    risks: list[RiskFlag] = Field(default_factory=list)


class ValuationData(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    enterprise_value: StrictFloat = Field(..., gt=0.0)
    ebitda: StrictFloat | None = None


class DealStructureInput(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    acquirer_market_cap: StrictFloat = Field(..., gt=0.0)
    valuation_data: ValuationData
    risk_flags: list[RiskFlag] = Field(default_factory=list)


class DealStructureOutput(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    recommended_structure: Literal["All Cash", "Stock Swap", "LBO", "Cash + Earn-out", "Hybrid"]
    tax_efficiency_score: StrictFloat = Field(..., ge=1.0, le=10.0)
    debt_capacity_warning: bool
    structuring_rationale: str = Field(..., min_length=20, max_length=2000)
    stock_consideration_pct: StrictFloat = Field(..., ge=0.0, le=1.0)
    estimated_dilution_pct: StrictFloat = Field(default=0.0, ge=0.0, le=100.0)


class NegotiationInput(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    target_enterprise_value: StrictFloat = Field(..., gt=0.0)
    total_annual_synergy: StrictFloat = Field(..., ge=0.0)
    risk_flags: list[RiskFlag] = Field(default_factory=list)
    recommended_structure: Literal["All Cash", "Stock Swap", "LBO", "Cash + Earn-out", "Hybrid"]


class NegotiationOutput(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    seller_leverage: Literal["High", "Medium", "Low"]
    recommended_opening_premium_pct: StrictFloat = Field(..., ge=0.0, le=100.0)
    opening_bid_price: StrictFloat = Field(..., ge=0.0)
    walk_away_price: StrictFloat = Field(..., ge=0.0)
    tactical_moves: list[str] = Field(default_factory=list, min_length=3, max_length=3)


class FullAnalysisRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    dcf_assumptions: DCFAssumptions
    acquirer_market_cap: StrictFloat = Field(..., gt=0.0)
    synergy_assumptions: SynergyAssumptions | None = None


class MasterDiligenceReport(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    deal_id: str
    company_a_financials: dict[str, Any] = Field(default_factory=dict)
    company_b_financials: dict[str, Any] = Field(default_factory=dict)
    valuation: dict[str, Any] | None = None
    synergies: dict[str, Any] = Field(default_factory=dict)
    legal_risks: dict[str, Any] | None = None
    deal_structure: dict[str, Any] | None = None
    negotiation_strategy: dict[str, Any] | None = None
    status_log: list[str] = Field(default_factory=list)


class LocalDraftRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    document_type: Literal["NDA", "LOI"]
    deal_name: str = Field(..., min_length=3, max_length=200)
    buyer_name: str = Field(..., min_length=2, max_length=200)
    seller_name: str = Field(..., min_length=2, max_length=200)
    jurisdiction: str = Field(default="Delaware", min_length=2, max_length=120)
    purchase_price: StrictFloat | None = Field(default=None, ge=0.0)
    exclusivity_days: StrictInt = Field(default=45, ge=1, le=180)


class LocalDraftResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    document_type: Literal["NDA", "LOI"]
    title: str
    key_terms: dict[str, Any] = Field(default_factory=dict)
    body: str


class LocalQAResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    document_name: str
    question: str
    answer: str
    supporting_quotes: list[str] = Field(default_factory=list, max_length=5)


class PublicDataSeriesResponse(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    source: str
    identifier: str
    observations: list[dict[str, str]] = Field(default_factory=list)


DealStageLiteral = Literal[
    "m1_hunt",
    "m2_approach",
    "m3_handshake",
    "m4_deep_dive",
    "m5_war_room",
    "m6_check",
    "m7_close",
    "m8_reality",
]


class DealCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    deal_name: str = Field(..., min_length=3, max_length=255)


class DealStageUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    stage: DealStageLiteral
    status: Literal["in_progress", "completed", "blocked"] = "in_progress"


class DealSummary(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    id: str
    deal_name: str
    stage: DealStageLiteral
    status: Literal["in_progress", "completed", "blocked"]
    created_at: str
    updated_at: str


class WarRoomMessageIn(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    sender_name: str = Field(default="anonymous", min_length=1, max_length=120)
    content: str = Field(..., min_length=1, max_length=4000)


class WarRoomMessageOut(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)

    deal_id: str
    sender_role: str
    sender_name: str
    content: str
    created_at: str
