from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class DealRecord(Base):
    __tablename__ = "deal_records"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    deal_name: Mapped[str] = mapped_column(String(255), default="Unnamed Deal")
    stage: Mapped[str] = mapped_column(String(64), default="m1_hunt")
    status: Mapped[str] = mapped_column(String(32), default="in_progress")

    company_a_financials: Mapped[dict] = mapped_column(JSON, default=dict)
    company_b_financials: Mapped[dict] = mapped_column(JSON, default=dict)
    valuation: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    synergies: Mapped[dict] = mapped_column(JSON, default=dict)
    legal_risks: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    deal_structure: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    negotiation_strategy: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    status_log: Mapped[list] = mapped_column(JSON, default=list)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utc_now, onupdate=utc_now
    )


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    deal_id: Mapped[str] = mapped_column(String(36), index=True)
    actor_role: Mapped[str] = mapped_column(String(32))
    action: Mapped[str] = mapped_column(String(128))
    details: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class WarRoomMessage(Base):
    __tablename__ = "war_room_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    deal_id: Mapped[str] = mapped_column(String(36), index=True)
    sender_role: Mapped[str] = mapped_column(String(32))
    sender_name: Mapped[str] = mapped_column(String(120), default="anonymous")
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
