import React from "react";
import { NavLink, Route, Routes } from "react-router-dom";
import HomePage from "./pages/HomePage";
import ApiGuidePage from "./pages/ApiGuidePage";
import DealsPage from "./pages/DealsPage";
import OrchestratorPage from "./pages/OrchestratorPage";
import WarRoomPage from "./pages/WarRoomPage";

const navItems = [
  { to: "/", label: "Executive Dashboard" },
  { to: "/deals", label: "Transaction Register" },
  { to: "/orchestrator", label: "Analysis Orchestration" },
  { to: "/war-room", label: "Negotiation Console" },
  { to: "/api-guide", label: "API & Data Hub" },
];

const tickerItems = [
  "S&P 500 +0.61%",
  "NASDAQ +0.83%",
  "US10Y 4.21%",
  "WTI 78.04",
  "DXY 103.88",
  "Global M&A Pipeline +12% QoQ",
];

export default function App() {
  return (
    <div className="terminal-shell">
      <header className="terminal-topbar">
        <div className="brand-block">
          <div className="brand-kicker">QuantumBlack Advisory Systems</div>
          <h1>Enterprise M&A Advisory Workstation</h1>
        </div>
        <div className="brand-meta">
          <span className="status-dot" />
          <span>LOCAL DEVELOPMENT ENVIRONMENT</span>
        </div>
      </header>

      <div className="ticker-strip">
        <div className="ticker-track">
          {tickerItems.concat(tickerItems).map((item, idx) => (
            <span key={`${item}-${idx}`}>{item}</span>
          ))}
        </div>
      </div>

      <div className="terminal-body">
        <aside className="left-rail">
          <div className="rail-title">Workstreams</div>
          <nav className="rail-nav">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/"}
                className={({ isActive }) => `rail-link ${isActive ? "active" : ""}`}
              >
                {item.label}
              </NavLink>
            ))}
          </nav>
          <div className="rail-footer">
            <p>Access Profile</p>
            <code>x-user-role: director</code>
          </div>
        </aside>

        <main className="terminal-main">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/deals" element={<DealsPage />} />
            <Route path="/orchestrator" element={<OrchestratorPage />} />
            <Route path="/war-room" element={<WarRoomPage />} />
            <Route path="/api-guide" element={<ApiGuidePage />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
