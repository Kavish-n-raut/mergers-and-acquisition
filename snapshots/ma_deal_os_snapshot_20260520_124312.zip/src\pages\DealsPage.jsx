import React, { useEffect, useMemo, useState } from "react";
import { createDeal, listDeals } from "../lib/api";

export default function DealsPage() {
  const [deals, setDeals] = useState([]);
  const [dealName, setDealName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const refresh = async () => {
    setLoading(true);
    setError("");
    try {
      const data = await listDeals(100);
      setDeals(data);
    } catch (e) {
      setError(e?.response?.data?.detail || e.message || "Failed to fetch transaction records.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  const onCreate = async () => {
    if (!dealName.trim()) return;
    setLoading(true);
    setError("");
    try {
      await createDeal(dealName.trim());
      setDealName("");
      await refresh();
    } catch (e) {
      setError(e?.response?.data?.detail || e.message || "Failed to create transaction record.");
      setLoading(false);
    }
  };

  const byStatus = useMemo(() => {
    const summary = { in_progress: 0, completed: 0, blocked: 0 };
    deals.forEach((d) => {
      if (summary[d.status] !== undefined) summary[d.status] += 1;
    });
    return summary;
  }, [deals]);

  return (
    <div className="page-grid">
      <section className="panel">
        <div className="panel-header">
          <h2>Transaction Intake</h2>
          <span className="chip">Lifecycle Workflow</span>
        </div>
        <div className="inline-form">
          <input
            value={dealName}
            onChange={(e) => setDealName(e.target.value)}
            placeholder="Northbridge Industrial Acquisition"
          />
          <button onClick={onCreate} disabled={loading}>
            Create Record
          </button>
          <button onClick={refresh} className="ghost-btn" disabled={loading}>
            Reload
          </button>
        </div>
        <div className="kpi-grid compact">
          <div className="kpi-card">
            <span>Total Records</span>
            <strong>{deals.length}</strong>
          </div>
          <div className="kpi-card">
            <span>Active Mandates</span>
            <strong>{byStatus.in_progress}</strong>
          </div>
          <div className="kpi-card">
            <span>Closed Mandates</span>
            <strong>{byStatus.completed}</strong>
          </div>
          <div className="kpi-card">
            <span>On-Hold Mandates</span>
            <strong>{byStatus.blocked}</strong>
          </div>
        </div>
        {error && <p className="error-text">{error}</p>}
      </section>

      <section className="panel">
        <div className="panel-header">
          <h3>Transaction Register</h3>
          <span className="chip chip-live">{loading ? "Synchronizing..." : "Synchronized"}</span>
        </div>
        <div className="table-wrap">
          <table className="terminal-table">
            <thead>
              <tr>
                <th>Transaction Name</th>
                <th>Lifecycle Stage</th>
                <th>Current Status</th>
                <th>Created On</th>
              </tr>
            </thead>
            <tbody>
              {deals.map((d) => (
                <tr key={d.id}>
                  <td>
                    <strong>{d.deal_name}</strong>
                    <span className="subtext">{d.id}</span>
                  </td>
                  <td>{d.stage}</td>
                  <td>
                    <span className={`status-pill status-${d.status}`}>{d.status}</span>
                  </td>
                  <td>{new Date(d.created_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!loading && deals.length === 0 && <p className="muted">No transaction records available yet.</p>}
        </div>
      </section>
    </div>
  );
}
