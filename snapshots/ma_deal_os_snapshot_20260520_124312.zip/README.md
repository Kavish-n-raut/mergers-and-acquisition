# QuantumBlack M&A Deal OS (PRD v3.0 Implementation MVP)

This repository contains a functional implementation MVP derived from `QuantumBlack_MADealOS_PRD_v3.pdf`:
- 8-phase lifecycle model (M1-M8) with stage transitions
- strict Pydantic contracts
- fault-tolerant orchestration
- deterministic financial boundaries
- local/free AI-alternative legal and strategy layers (Anthropic optional)
- war-room messaging (REST + WebSocket)
- deal persistence + audit logs

## Stack
- Backend: Python, FastAPI, Pydantic v2, SQLAlchemy
- AI/RAG: local deterministic pipeline by default, Anthropic Claude optional
- Async: Celery + Redis (skeleton)
- Output automation: python-pptx
- Frontend: React + Vite

## Quick Start

### 1) Backend
```bash
cd backend
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload --port 8000
```

Open docs at `http://127.0.0.1:8000/docs`

### Local/Free mode (default)
- `AI_PROVIDER=local` and `USE_ANTHROPIC=false` are the defaults.
- No Anthropic key is required for:
  - document scanning (rule-based),
  - deal structuring (deterministic),
  - negotiation playbook (rule-based + hard math),
  - document Q&A retrieval,
  - NDA/LOI drafting templates.
- Free/public source integration available in API:
  - SEC EDGAR (`/public-data/sec/companyfacts/{cik}`)
  - FRED (`/public-data/fred/{series_id}`)
  - U.S. Treasury FiscalData (`/public-data/treasury-yields`)
  - Stooq (`/public-data/stooq/{symbol}`)
  - Reference links for Damodaran, CUAD, SEC exhibits, FTC/EU/CMA/CFIUS (`/public-data/references`)

### Optional Anthropic premium mode
Set all three:
```bash
AI_PROVIDER=anthropic
USE_ANTHROPIC=true
ANTHROPIC_API_KEY=sk-ant-...
```

### 2) Frontend
```bash
cd frontend
npm install
copy .env.example .env
npm run dev
```

Open app at `http://127.0.0.1:5173`

## Key Endpoints
- `POST /api/v1/deals`
- `GET /api/v1/health/llm`
- `PATCH /api/v1/deals/{deal_id}/stage`
- `GET /api/v1/deals/{deal_id}/war-room/messages`
- `POST /api/v1/deals/{deal_id}/war-room/messages`
- `WS  /api/v1/ws/war-room/{deal_id}`
- `POST /api/v1/modules/m1/screen-targets`
- `POST /api/v1/draft-document/`
- `POST /api/v1/financial/ratios`
- `POST /api/v1/valuation/dcf`
- `POST /api/v1/calculate-synergies/`
- `POST /api/v1/scan-document/`
- `POST /api/v1/document-qa/`
- `POST /api/v1/structure-deal/`
- `POST /api/v1/negotiation-strategy/`
- `POST /api/v1/run-full-analysis/`
- `POST /api/v1/download-pitchbook/`
- `GET /api/v1/deals/{deal_id}/pitchbook`
- `GET /api/v1/public-data/references`
- `GET /api/v1/public-data/fred/{series_id}`
- `GET /api/v1/public-data/treasury-yields`
- `GET /api/v1/public-data/stooq/{symbol}`
- `GET /api/v1/public-data/sec/companyfacts/{cik}`
- `GET /api/v1/synthetic-data`
- `GET /api/v1/synthetic-data/{dataset_name}`

## Tests
```bash
cd backend
pytest -q
```

## Notes
- Anthropic is optional; free/local mode is default and fully functional.
- If Anthropic mode is enabled without a valid key, only Anthropic-specific calls degrade.
- Orchestrator is stage-fault-tolerant: if legal scan fails, downstream finance/strategy still return.
- DB defaults to SQLite for local dev. Set `DATABASE_URL` for PostgreSQL.
- Role-based access is enforced via API header: `x-user-role` (`analyst|associate|vp|director|md|admin`).
