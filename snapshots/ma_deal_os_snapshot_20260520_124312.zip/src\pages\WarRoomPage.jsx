import React, { useEffect, useRef, useState } from "react";
import { listWarRoomMessages, postWarRoomMessage, warRoomWebSocketUrl } from "../lib/api";

export default function WarRoomPage() {
  const [dealId, setDealId] = useState("");
  const [senderName, setSenderName] = useState("Analyst");
  const [content, setContent] = useState("");
  const [messages, setMessages] = useState([]);
  const [error, setError] = useState("");
  const [connected, setConnected] = useState(false);
  const wsRef = useRef(null);

  const connect = async () => {
    if (!dealId.trim()) return;
    setError("");
    try {
      const initial = await listWarRoomMessages(dealId.trim());
      setMessages(initial.messages || []);
    } catch (e) {
      setError(e?.response?.data?.detail || "Failed to load historical negotiation updates.");
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    const ws = new WebSocket(warRoomWebSocketUrl(dealId.trim()));
    wsRef.current = ws;
    ws.onopen = () => setConnected(true);
    ws.onclose = () => setConnected(false);
    ws.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data);
        if (parsed.system_event) return;
        setMessages((prev) => [...prev, parsed]);
      } catch {
        // ignore malformed frame
      }
    };
    ws.onerror = () => setError("WebSocket connection error.");
  };

  useEffect(() => {
    return () => {
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  const sendMessage = async () => {
    if (!dealId.trim() || !content.trim()) return;
    setError("");
    try {
      await postWarRoomMessage(dealId.trim(), senderName.trim() || "Analyst", content.trim());
      setContent("");
    } catch (e) {
      setError(e?.response?.data?.detail || "Failed to publish negotiation update.");
    }
  };

  return (
    <div className="page-grid warroom-grid">
      <section className="panel">
        <div className="panel-header">
          <h2>Negotiation Command Center</h2>
          <span className={`chip ${connected ? "chip-live" : ""}`}>{connected ? "Connected" : "Disconnected"}</span>
        </div>
        <div className="form-stack">
          <label>
            Transaction ID
            <input placeholder="Enter transaction UUID" value={dealId} onChange={(e) => setDealId(e.target.value)} />
          </label>
          <label>
            Participant Name
            <input value={senderName} onChange={(e) => setSenderName(e.target.value)} />
          </label>
          <button onClick={connect}>Connect Session</button>
        </div>
        {error && <p className="error-text">{error}</p>}
      </section>

      <section className="panel">
        <div className="panel-header">
          <h3>Negotiation Activity Feed</h3>
          <span className="chip">{messages.length} entries</span>
        </div>
        <div className="feed-window">
          {messages.map((m, i) => (
            <article key={`${m.created_at || i}-${i}`} className="feed-item">
              <div className="feed-meta">
                <strong>{m.sender_name || "Unknown"}</strong>
                <span>{m.sender_role || "role"}</span>
              </div>
              <p>{m.content}</p>
            </article>
          ))}
          {messages.length === 0 && <p className="muted">No activity in this session yet.</p>}
        </div>
        <div className="inline-form">
          <textarea
            rows={3}
            placeholder="Enter negotiation update or escalation note..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
          <button onClick={sendMessage}>Post Update</button>
        </div>
      </section>
    </div>
  );
}
