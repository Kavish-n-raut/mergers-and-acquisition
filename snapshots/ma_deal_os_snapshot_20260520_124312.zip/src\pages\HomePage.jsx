import React, { useEffect, useMemo, useState } from "react";
import { getHealth, getLlmHealth, listDeals } from "../lib/api";

const modules = [
  "M1 Origination Screening",
  "M2 Initial Outreach",
  "M3 Indicative Alignment",
  "M4 Due Diligence",
  "M5 Negotiation Management",
  "M6 Regulatory Review",
  "M7 Transaction Closing",
  "M8 Post-Merger Integration",
];

export default function HomePage() {
  const [health, setHealth] = useState(null);
  const [llmHealth, setLlmHealth] = useState(null);
  const [deals, setDeals] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const boot = async () => {
      setError("");
      try {
        const [core, llm, dealRows] = await Promise.all([getHealth(), getLlmHealth(), listDeals(100)]);
        setHealth(core);
        setLlmHealth(llm);
        setDeals(Array.isArray(dealRows) ? dealRows : []);
      } catch (e) {
        setError(e?.response?.data?.detail || e.message || "Unable to load dashboard overview.");
      }
    };
    boot();
  }, []);

  const inFlightCount = useMemo(
    () => deals.filter((d) => d.status === "in_progress").length,
    [deals]
  );

  return (
    <div className="page-grid">
      <section className="panel">
        <div className="panel-header">
          <h2>Transaction Oversight Dashboard</h2>
          <span className="chip chip-live">Real-Time View</span>
        </div>
        <p className="muted">
          Central oversight for valuation, due diligence, structuring, and negotiation workstreams.
        </p>
        <div className="kpi-grid">
          <div className="kpi-card">
            <span>Total Transactions</span>
            <strong>{deals.length}</strong>
          </div>
          <div className="kpi-card">
            <span>Active Mandates</span>
            <strong>{inFlightCount}</strong>
          </div>
          <div className="kpi-card">
            <span>Core Platform</span>
            <strong>{health?.status || "..."}</strong>
          </div>
          <div className="kpi-card">
            <span>Decision Engine</span>
            <strong>{llmHealth?.provider || "..."}</strong>
          </div>
        </div>
        {error && <p className="error-text">{error}</p>}
      </section>

      <section className="panel">
        <div className="panel-header">
          <h3>Transaction Lifecycle Framework</h3>
          <span className="chip">M1-M8 Model</span>
        </div>
        <div className="module-grid">
          {modules.map((m) => (
            <article key={m} className="module-card">
              <h4>{m}</h4>
              <p>Integrated execution module</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
